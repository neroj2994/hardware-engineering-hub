Hardware Engineering Hub — install on iPhone (no Mac, no App Store)
====================================================================

This folder is a PWA (Progressive Web App). Host it once, then it
installs on your iPhone like an app: own icon, full screen, works
offline after the first visit.

STEP 1 — Put it online (one time, free, ~1 minute)
  Easiest: https://app.netlify.com/drop
    - Drag this whole folder onto the page (no account needed to try,
      free account to keep it permanently).
    - You get a URL like  https://something.netlify.app
  Any static host works the same (Cloudflare Pages, Vercel, GitHub
  Pages). It must be HTTPS — all of these are.

STEP 2 — Install on the iPhone
  1. Open the URL in Safari (must be Safari, not Chrome).
  2. Tap the Share button (square with arrow).
  3. Tap "Add to Home Screen"  →  Add.
  4. Launch "HW Hub" from your home screen.

What works offline after first launch:
  - All 63 calculators, VRM designer + Loop Comp, PDN planner,
    Channel designer, Interface Reach — everything computes on-device.
  - The Simulator tab needs internet (it uses the hosted CircuitJS
    on the phone; the 18 MB offline copy is only in the Windows app).

Updating later:
  Re-drop a new folder on Netlify; the app picks it up next launch
  (the service worker refreshes its cache automatically by version).

Notes
  - Nothing is sent anywhere: all math runs in the browser on the
    phone. Hosting is only used to deliver the files.
  - If your company network blocks netlify.app, use any host IT
    allows, or install it over home Wi-Fi once — after that it
    runs offline anywhere.
