# Hardware Engineering Hub — changelog

## v1.0.0 — first deployed release
- 63 calculators in 7 groups (Basics, Analog, Signal Integrity, Power,
  PDN, FPGA & Logic, Networking)
- VRM Designer: buck, LDO, multiphase, and Loop Compensation with live
  Bode plot, phase-margin verdict and compensator component values
- PDN Planner with automatic capacitor optimizer
- Channel Designer (insertion-loss budget) and Interface Reach table
  (42 interfaces incl. QSGMII, USXGMII, JTAG, eSPI)
- Knowledge Hub: 28 curated topics for network-hardware design
- Instrument-glass UI, light/dark, hover-or-always learn notes
- PWA: offline after first load, iPhone Add-to-Home-Screen
- by Niroj Kapri
