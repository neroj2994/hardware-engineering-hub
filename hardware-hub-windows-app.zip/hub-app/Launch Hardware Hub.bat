@echo off
REM ============================================================
REM  Launch Hardware Engineering Hub
REM  Tries, in order: installed app -> portable exe -> Electron dev
REM  -> Edge app window (always works, no build needed)
REM ============================================================
title Hardware Engineering Hub
cd /d "%~dp0"

REM 1) installed via NSIS (per-user)
set "INST=%LOCALAPPDATA%\Programs\hardware-engineering-hub\Hardware Engineering Hub.exe"
if exist "%INST%" ( start "" "%INST%" & exit /b )

REM 2) portable / built exe in release folder
if exist "release\Hardware Engineering Hub 1.0.0.exe" ( start "" "release\Hardware Engineering Hub 1.0.0.exe" & exit /b )
for %%F in ("release\*.exe") do ( start "" "%%F" & exit /b )

REM 3) run with Electron directly (no build needed) if deps are installed
if exist "node_modules\.bin\electron.cmd" ( call node_modules\.bin\electron.cmd . & exit /b )

REM 4) fallback: open in Edge as an app window (always works)
set "HUB=%~dp0dist\index.html"
start "" msedge --app="file:///%HUB:\=/%" 2>nul
if errorlevel 1 start "" chrome --app="file:///%HUB:\=/%" 2>nul
if errorlevel 1 start "" "%HUB%"
exit /b
