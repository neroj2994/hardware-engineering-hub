@echo off
title Hardware Engineering Hub
cd /d "%~dp0"
REM Runs the app that BUILD-EXE already produced, even if the installer step failed.
if exist "release\Hardware Engineering Hub.exe" ( start "" "release\Hardware Engineering Hub.exe" & exit /b )
if exist "release\win-unpacked\Hardware Engineering Hub.exe" ( start "" "release\win-unpacked\Hardware Engineering Hub.exe" & exit /b )
echo Could not find a built app yet. Run BUILD-EXE.bat first.
pause
