// Electron main process — Hardware Engineering Hub
const { app, BrowserWindow, shell } = require("electron");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: "#f6f8fc",
    autoHideMenuBar: true,
    icon: path.join(__dirname, "build", "icon.png"),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  const indexPath = path.join(__dirname, "dist", "index.html");
  win.loadFile(indexPath).catch((err) => {
    console.error("Failed to load index.html:", err);
  });

  // If the page fails to render, surface it instead of a blank white screen
  win.webContents.on("did-fail-load", (e, code, desc) => {
    console.error("did-fail-load", code, desc);
    win.webContents.openDevTools({ mode: "detach" });
  });
  win.webContents.on("render-process-gone", (e, details) => {
    console.error("render-process-gone", details);
  });

  // open external links (API console, etc.) in the default browser
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  // Uncomment to debug:
  // win.webContents.openDevTools({ mode: "detach" });
}

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
