@echo off
REM Launches the Hub as a standalone app window using Microsoft Edge (no install needed)
set HUB=%~dp0dist\index.html
start "" msedge --app="file:///%HUB:\=/%"
