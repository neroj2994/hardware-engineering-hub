@echo off
REM ============================================================
REM  Hardware Engineering Hub - one-click Windows .exe builder
REM  Double-click this file. It installs what's needed and
REM  produces the .exe in the "release" folder.
REM ============================================================
title Building Hardware Engineering Hub .exe
color 0B
echo.
echo  ============================================================
echo    Hardware Engineering Hub  -  Windows .exe builder
echo  ============================================================
echo.

REM --- check Node.js ---
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo  [X] Node.js is not installed.
  echo.
  echo  Please install Node.js LTS first from:  https://nodejs.org
  echo  Then double-click this file again.
  echo.
  pause
  exit /b 1
)
echo  [OK] Node.js found:
node --version
echo.

REM --- corporate proxy SSL workaround (same as your Headroom setup) ---
echo  Applying SSL workaround for corporate networks...
call npm config set strict-ssl false >nul 2>nul

REM --- install dependencies ---
echo  Installing dependencies (first run only, ~2-3 min)...
call npm install --no-audit --no-fund
if %errorlevel% neq 0 (
  echo  [X] npm install failed. If you are behind a corporate proxy,
  echo      ask IT for the proxy URL and run:
  echo          npm config set proxy http://YOURPROXY:PORT
  echo          npm config set https-proxy http://YOURPROXY:PORT
  echo      then double-click this file again.
  pause
  exit /b 1
)
call npm install --no-audit --no-fund -D electron electron-builder
if %errorlevel% neq 0 ( echo  [X] Could not install electron tools. & pause & exit /b 1 )

REM --- rebuild the app bundle from source (in case it was edited) ---
echo.
echo  Rebuilding app bundle from source...
call npm run rebuild
if %errorlevel% neq 0 ( echo  [!] Rebuild step skipped/failed - using existing bundle. )

REM --- SSL workaround for corporate cert inspection (the cause of the
REM     "self-signed certificate in certificate chain" build failure) ---
echo.
echo  Applying corporate-certificate workaround for the build step...
set NODE_TLS_REJECT_UNAUTHORIZED=0
set CSC_IDENTITY_AUTO_DISCOVERY=false
set ELECTRON_BUILDER_OFFLINE=true

REM --- build the .exe ---
echo.
echo  Building the Windows .exe (this takes a few minutes)...
call npm run dist
if %errorlevel% neq 0 (
  echo.
  echo  [!] Installer step failed - this is almost always the corporate
  echo      firewall blocking a download. But the APP ITSELF was built.
  echo.
  echo  Looking for the ready-to-run app in release\win-unpacked ...
  if exist "release\win-unpacked\Hardware Engineering Hub.exe" (
    echo  [OK] Found it! Your working app is here:
    echo        release\win-unpacked\Hardware Engineering Hub.exe
    echo  You can run it directly, or make a desktop shortcut to it.
    start "" "release\win-unpacked"
    echo.
    pause
    exit /b 0
  ) else (
    echo  [X] Could not find the unpacked app either. See messages above.
    echo      Try: ask IT for the proxy URL, then run in this folder:
    echo          npm config set proxy http://YOURPROXY:PORT
    echo          npm config set https-proxy http://YOURPROXY:PORT
    pause
    exit /b 1
  )
)

echo.
echo  ============================================================
echo    DONE!  Your .exe files are in the "release" folder:
echo.
echo      - Hardware Engineering Hub.exe   (portable - just run it)
echo  ============================================================
echo.
REM open the output folder
if exist "release" ( start "" "release" ) else ( if exist "dist_electron" start "" "dist_electron" )
pause
