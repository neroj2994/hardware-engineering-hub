import React from "react";
import { createRoot } from "react-dom/client";
import HardwareHub from "./HardwareHub.jsx";
createRoot(document.getElementById("root")).render(<HardwareHub />);
