// Rebuilds the app bundle + CSS from src/ (run by: npm run rebuild)
// Uses esbuild's JS API so the NODE_ENV define is quoted correctly
// (passing --define through a shell mangles the quotes -> "production is not defined").
const esbuild = require("esbuild");
const { execSync } = require("child_process");

esbuild.build({
  entryPoints: ["src/index.jsx"],
  bundle: true,
  minify: true,
  jsx: "automatic",
  loader: { ".jsx": "jsx" },
  define: { "process.env.NODE_ENV": JSON.stringify("production") },
  outfile: "dist/bundle.js",
}).then(() => {
  console.log("> bundle.js built");
  execSync("npx tailwindcss -c tailwind.config.js -i src/input.css -o dist/tw.css --minify", { stdio: "inherit" });
  console.log("Rebuild complete.");
}).catch((e) => { console.error(e); process.exit(1); });
