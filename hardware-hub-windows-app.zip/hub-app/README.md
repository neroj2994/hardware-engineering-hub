# Hardware Engineering Hub — Windows App

PCB calculators (40, with live diagrams + formulas), Interface Reach tables,
Channel loss Designer, PDN Planner with auto-suggestions, and a 3-topology VRM
Designer (Buck / LDO / Multiphase) — plus an AI hardware engineer with
file/datasheet attachments. Light + dark theme.

Everything is fully offline EXCEPT the AI chat (needs internet + your own
Anthropic API key from console.anthropic.com).

============================================================
 MAKE A .EXE  —  the easy way (recommended)
============================================================
1. Install Node.js LTS once, from https://nodejs.org  (you likely already
   have it from your Claude Code setup).
2. Double-click  BUILD-EXE.bat
3. Wait a few minutes. When it finishes, the "release" folder opens with:
      - Hardware Engineering Hub Setup 1.0.0.exe   <- installer (desktop shortcut)
      - Hardware Engineering Hub 1.0.0.exe         <- portable (run from anywhere, USB OK)

That's it. No commands to type. The .bat handles install + build for you,
including the corporate-proxy SSL workaround.

============================================================
 RUN WITHOUT BUILDING  —  instant, no .exe
============================================================
- Double-click  Run-as-App (Edge).bat   -> opens in its own app window now.
- Or open  dist/index.html  in any browser (works offline).

============================================================
 MANUAL BUILD (if you prefer the command line)
============================================================
    npm install
    npm install -D electron electron-builder
    npm run dist
Output -> release/ folder.

Corporate proxy note: if npm fails with SSL errors,
    npm config set strict-ssl false
(or set proxy:  npm config set proxy http://YOURPROXY:PORT  and https-proxy too).

============================================================
 EDITING LATER
============================================================
Source is  src/HardwareHub.jsx . After editing:
    npm run rebuild      (rebuilds dist/bundle.js + dist/tw.css)
then relaunch or re-run BUILD-EXE.bat to make a fresh .exe.

============================================================
 AI CHAT
============================================================
Open the AI Engineer tab, click "Set Anthropic API key", paste a key from
console.anthropic.com. Key stays in memory only (gone when the app closes).
The 40 calculators, Interface Reach, Channel Designer, PDN and VRM tools
never need a key and never need internet.

============================================================
 WHITE SCREEN AFTER INSTALL?  (fixed in this version)
============================================================
This build disables asar packaging and adds an on-screen error catcher,
which resolves the most common blank-screen causes. If you still see white:

1. Use  "Launch Hardware Hub.bat"  -> it auto-falls-back to an Edge app
   window or Electron if the installed exe misbehaves.
2. Rebuild fresh:  delete the  release  folder, then double-click BUILD-EXE.bat
   again (it now rebuilds the bundle first).
3. To see the actual error: the app now auto-opens DevTools on load failure,
   or open  dist/index.html  directly in a browser — any startup error shows
   in red text instead of a blank page.

============================================================
 LAUNCHER .BAT FILES INCLUDED
============================================================
- Launch Hardware Hub.bat        -> smart launcher: finds the installed or
                                     portable exe, else Electron, else Edge.
                                     Use this as your everyday shortcut.
- Run-as-App (Edge).bat           -> instant app window, zero install.
- Run-with-Electron (no build).bat-> runs via Electron (installs it once),
                                     no exe build needed.
- BUILD-EXE.bat                   -> makes the installer + portable exe.

============================================================
 BUILD FAILED with "self-signed certificate in chain"?
============================================================
That is your company's network inspecting HTTPS — it blocks a download
electron-builder tries to make. This is now handled automatically:

- The build is set to "portable" (a single .exe, no installer download).
- BUILD-EXE.bat sets the corporate-cert bypass env vars before building.
- Even if the build step still fails, the WORKING APP is already produced
  in  release\win-unpacked\Hardware Engineering Hub.exe  — the script will
  point you to it, or just double-click  "Run Built App.bat".

So you have three ways to run it, all offline:
  1. release\Hardware Engineering Hub.exe        (portable, after build)
  2. release\win-unpacked\Hardware Engineering Hub.exe   (always made)
  3. "Run Built App.bat"                          (finds whichever exists)
