@echo off
title Hardware Engineering Hub - Electron
cd /d "%~dp0"
where node >nul 2>nul || ( echo Install Node.js LTS from https://nodejs.org first. & pause & exit /b 1 )
call npm config set strict-ssl false >nul 2>nul
if not exist "node_modules\electron" (
  echo Installing Electron once...
  call npm install --no-audit --no-fund -D electron
)
echo Launching...
call node_modules\.bin\electron.cmd .
